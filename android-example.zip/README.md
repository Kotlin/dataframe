# 📱 Android Example

A minimal Android project showcasing integration with **Kotlin DataFrame**.

<p align="center">
  <img src="screen.jpg" alt="App screenshot" height="320"/>
</p>

It also includes the [Kotlin DataFrame Compiler Plugin](https://kotlin.github.io/dataframe/compiler-plugin.html).

We recommend using an up-to-date Android Studio for the best experience.
Proper functionality in Android Studio requires version Otter | 2025.2.3 or newer.

[Download Android Example](https://github.com/Kotlin/dataframe/raw/example-projects-archives/android-example.zip)

